function setup() {
  createCanvas(800, 400);
  noLoop();
}

function draw() {
  background(135, 206, 235); // céu azul

  // Sol
  fill(255, 204, 0);
  ellipse(100, 80, 60, 60);

  drawField(0, 0, width / 2, height); // campo no lado esquerdo
  drawCity(width / 2, 0, width / 2, height); // cidade no lado direito
}

function drawField(x, y, w, h) {
  // Grama
  fill(34, 139, 34);
  rect(x, h / 2, w, h / 2);

  // Casinha
  fill(210, 180, 140);
  rect(x + 100, h / 2 - 60, 80, 60);
  fill(139, 69, 19);
  triangle(x + 90, h / 2 - 60, x + 140, h / 2 - 100, x + 190, h / 2 - 60);

  // Árvore 1
  drawTree(x + 50, h / 2 - 20);
  drawTree(x + 200, h / 2 - 30);
  drawTree(x + 150, h / 2 - 10);
}

function drawTree(x, y) {
  fill(139, 69, 19);
  rect(x, y, 10, 40);
  fill(34, 139, 34);
  ellipse(x + 5, y, 40, 40);
}

function drawCity(x, y, w, h) {
  // Asfalto
  fill(169, 169, 169);
  rect(x, h / 2, w, h / 2);

  // Prédios
  for (let i = 0; i < 4; i++) {
    let px = x + 50 + i * 80;
    let ph = random(100, 200);
    fill(100);
    rect(px, h / 2 - ph, 60, ph);

    // Janelas
    fill(255, 255, 102);
    for (let j = 0; j < ph / 30; j++) {
      for (let k = 0; k < 2; k++) {
        rect(px + 10 + k * 25, h / 2 - ph + 10 + j * 30, 10, 15);
      }
    }

    // Fumaça (representa poluição)
    fill(120, 120, 120, 100);
    for (let s = 0; s < 5; s++) {
      ellipse(px + 30, h / 2 - ph - s * 15, 30 - s * 3, 20 - s * 2);
    }
  }
}